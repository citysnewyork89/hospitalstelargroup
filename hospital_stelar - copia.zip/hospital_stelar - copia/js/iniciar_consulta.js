document.addEventListener("DOMContentLoaded", () => {
  const ingresoSelect = document.getElementById("ingreso-select");
  const datosIngreso = document.getElementById("datos-ingreso");
  const btnGenerar = document.getElementById("btn-generar");
  const form = document.getElementById("form-consulta");

  // Mostrar/ocultar campos de ingreso según selección
  ingresoSelect.addEventListener("change", () => {
    datosIngreso.style.display = ingresoSelect.value === "si" ? "block" : "none";
  });

  // Función para recoger datos del formulario
  function recogerDatosFormulario() {
    const datos = new FormData(form);
    return {
      nombre: datos.get("nombre_paciente"),
      empleado: datos.get("nombre_empleado"),
      numeroCita: datos.get("numero_cita"),
      fecha: datos.get("fecha"),
      id: datos.get("id_paciente") || "No especificado",
      asunto: datos.get("asunto"),
      descripcion: datos.get("descripcion"),
      receta: datos.get("receta"),
      ingreso: datos.get("ingreso") === "si" ? "Sí" : "No",
      areaIngreso: datos.get("sala_ingreso") || "",
      motivoIngreso: datos.get("motivo_ingreso") || "",
      categoria: datos.get("categoria") || "",
      categoriaPersonalizada: datos.get("categoria_personalizada") || "",
      fechaIngreso: datos.get("fecha_ingreso") || "",
      notaDoctor: datos.get("nota_doctor") || ""
    };
  }

  // Guardar en historial de consultas
  function guardarEnHistorial(consulta) {
    const historial = JSON.parse(localStorage.getItem("historialConsultas") || "[]");
    historial.push(consulta);
    localStorage.setItem("historialConsultas", JSON.stringify(historial));
  }

  // Generar ticket
  btnGenerar.addEventListener("click", () => {
    const datosConsulta = recogerDatosFormulario();

    // Guardar en localStorage con clave unificada
    localStorage.setItem("ticketConsultaData", JSON.stringify(datosConsulta));

    // Guardar en historial
    guardarEnHistorial(datosConsulta);

    // Redirigir al ticket
    window.location.href = "../tickets/ticket_consulta.html";
  });
});
